import { Link } from "react-router-dom";
import './Header.css';
import React from "react";
import LoginComponent from "../pages/LoginComponent";
import Error from "../pages/Error" ;
function MainNavigation(){
  
    return(
     
      
        <header className="header">
            <div className="header-top">
            <div className="logo">
                    <Link to="/">
                        <img src={'../image/PopConB.png'} alt="PopConB.png" />
                    </Link>
                    <span className="brand">POP<span className="highlight">CON</span></span>
                </div>
                <nav className="top-nav">
                    <Link to="/login" className="nav-link">로그인</Link>
                    <Link to="/customer" className="nav-link">고객센터</Link>
                </nav>
            </div>
            <div className="header-bottom">
                <div className="search-bar">
                    <input type="text" placeholder="Search" />
                    <button type="submit">Q</button>
                </div>
                <nav className="main-nav">
            <Link to="/MyPage">마이페이지</Link>
            <Link to="/usersSearch">Search</Link>
            <Link to="/product1">1 + 1</Link>
            <Link to="/product2">2 + 1</Link>
            <Link to="/productonsale">할인</Link>
            <Link to="/usersAdd">덤증정</Link>
            <Link to="/usersAdd">이벤트</Link>
            </nav>
          </div>

      </header>

   
  );
}

export default MainNavigation;