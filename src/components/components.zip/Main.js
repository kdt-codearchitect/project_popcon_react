import React from 'react';
import { Routes, Route } from 'react-router-dom';
import LoginComponent from "../pages/LoginComponent";
import HomeComponent from "../pages/HomeComponent";
import ProductComponent from "../pages/ProductComponent";
import Error from "../pages/Error" ;
import './Main.css';
import { Link } from 'react-router-dom';

const Main = () => {
    document.addEventListener('DOMContentLoaded', function(){
        function loadContent(url){
    fetch(LoginComponent)
    .then(response => Error.text())
    .then(data => {
        document.getElementById('content').innerHTML = data;
        })
        .catch(error => console.error('Error loading content: ', error));
        }
        loadContent('main-content.html');
    })
    return (
        <main>
            <Routes>
                <Route path="/" element={<HomeComponent />} />
                <Route path="/login" element={<LoginComponent />} />
                <Route path="/product1" element={<ProductComponent />} />
            
            </Routes>
        </main>
    );
};

export default Main;