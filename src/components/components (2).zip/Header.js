import { Link } from "react-router-dom";
import './Header.css';
import React from "react";
import LoginComponent from "../pages/LoginComponent";
import Error from "../pages/Error" ;

function MainNavigation(){
  
    return(
     
      <header>
        <div className="header-decor">
          {/* <div className="header-stick"> */}
          <div className="nav-links">
            <Link to="/">Home</Link>
            <Link to="/login">로그인</Link>
            <Link to="/MyPage">마이페이지</Link>
            <Link to="/usersSearch">Search</Link>
            <Link to="/product1">1 + 1</Link>
            <Link to="/product2">2 + 1</Link>
            <Link to="/usersSearch">할인</Link>
            <Link to="/usersAdd">덤증정</Link>
            <Link to="/usersAdd">이벤트</Link>
            <Link to="/usersAdd">고객센터</Link>
            
          </div>
          
        {/* </div> */}
        </div>
      </header>

   
  );
}

export default MainNavigation;