import './ProductComponent3.css';
import MTc0NDA2 from "../image/products/MTc0NDA2.png";
function ProductComponent3() {
  return (
<div className="product-grid__wrapper">
		<div className="product-grid__wrap">
		<div className="product-grid__container">
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5CzxImgqxRrfskrvpk_LFIl4k0hdOuEwP5Q&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYBcD5DUz0l5cvUfruppZrnjpXuWUGdbam0Q&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSy4OTA72dxCtKGatqXYs95gC4Q_7HxsLGmsA&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQz2lw9If32rgngeaa8gi8ng1Xmrxr-qYOeGA&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5CzxImgqxRrfskrvpk_LFIl4k0hdOuEwP5Q&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYBcD5DUz0l5cvUfruppZrnjpXuWUGdbam0Q&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSy4OTA72dxCtKGatqXYs95gC4Q_7HxsLGmsA&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQz2lw9If32rgngeaa8gi8ng1Xmrxr-qYOeGA&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5CzxImgqxRrfskrvpk_LFIl4k0hdOuEwP5Q&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYBcD5DUz0l5cvUfruppZrnjpXuWUGdbam0Q&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSy4OTA72dxCtKGatqXYs95gC4Q_7HxsLGmsA&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQz2lw9If32rgngeaa8gi8ng1Xmrxr-qYOeGA&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5CzxImgqxRrfskrvpk_LFIl4k0hdOuEwP5Q&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYBcD5DUz0l5cvUfruppZrnjpXuWUGdbam0Q&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSy4OTA72dxCtKGatqXYs95gC4Q_7HxsLGmsA&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQz2lw9If32rgngeaa8gi8ng1Xmrxr-qYOeGA&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5CzxImgqxRrfskrvpk_LFIl4k0hdOuEwP5Q&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYBcD5DUz0l5cvUfruppZrnjpXuWUGdbam0Q&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSy4OTA72dxCtKGatqXYs95gC4Q_7HxsLGmsA&s.jpg"/>
				</div>
			</article>
			<article class="card">
				<div class="product-card-image">
				<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQz2lw9If32rgngeaa8gi8ng1Xmrxr-qYOeGA&s.jpg"/>
				</div>
			</article>
			
		</div>
		</div>
	</div>
  );
}

export default ProductComponent3;
