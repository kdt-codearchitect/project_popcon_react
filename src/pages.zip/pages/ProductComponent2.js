import './ProductComponent2.css';
import MTc0NDA2 from "../image/products/MTc0NDA2.png";
function ProductComponent2() {
  return (
<div className="product-grid__wrapper">
		<div className="product-grid__wrap">
		<div className="product-grid__container">
		<article className="card">
            <div className="product-card-image">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQtg5CsXcBWxl7aSa0sGZuDOwpSSFb4eKIPw&s.jpg" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">난 마카오</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
			
		<article className="card">
            <div className="product-card-image">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBJ1I4Me580mSBEctbU7oIbSGOz9Q27lE5Ig&s.jpg" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">난 조마</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
			
		<article className="card">
            <div className="product-card-image">
                <img src="https://i.namu.wiki/i/phJJ4yav60AY8ao5brb4JDnoqP0ZFJk3zaqLnE9l760V5ubk2b67VUnQzz73oeVaJRm49I_Fr32QqU36RyddNw.webp" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">우리 사이좋게 지내요</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
		
		<article className="card">
            <div className="product-card-image">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQtg5CsXcBWxl7aSa0sGZuDOwpSSFb4eKIPw&s.jpg" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">난 마카오</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
			
		<article className="card">
            <div className="product-card-image">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBJ1I4Me580mSBEctbU7oIbSGOz9Q27lE5Ig&s.jpg" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">난 조마</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
			
		<article className="card">
            <div className="product-card-image">
                <img src="https://i.namu.wiki/i/phJJ4yav60AY8ao5brb4JDnoqP0ZFJk3zaqLnE9l760V5ubk2b67VUnQzz73oeVaJRm49I_Fr32QqU36RyddNw.webp" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">우리 사이좋게 지내요</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
		
		<article className="card">
            <div className="product-card-image">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQtg5CsXcBWxl7aSa0sGZuDOwpSSFb4eKIPw&s.jpg" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">난 마카오</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
			
		<article className="card">
            <div className="product-card-image">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBJ1I4Me580mSBEctbU7oIbSGOz9Q27lE5Ig&s.jpg" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">난 조마</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
			
		<article className="card">
            <div className="product-card-image">
                <img src="https://i.namu.wiki/i/phJJ4yav60AY8ao5brb4JDnoqP0ZFJk3zaqLnE9l760V5ubk2b67VUnQzz73oeVaJRm49I_Fr32QqU36RyddNw.webp" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">우리 사이좋게 지내요</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
		
		<article className="card">
            <div className="product-card-image">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQtg5CsXcBWxl7aSa0sGZuDOwpSSFb4eKIPw&s.jpg" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">난 마카오</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
			
		<article className="card">
            <div className="product-card-image">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBJ1I4Me580mSBEctbU7oIbSGOz9Q27lE5Ig&s.jpg" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">난 조마</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
			
		<article className="card">
            <div className="product-card-image">
                <img src="https://i.namu.wiki/i/phJJ4yav60AY8ao5brb4JDnoqP0ZFJk3zaqLnE9l760V5ubk2b67VUnQzz73oeVaJRm49I_Fr32QqU36RyddNw.webp" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">우리 사이좋게 지내요</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
		
		<article className="card">
            <div className="product-card-image">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQtg5CsXcBWxl7aSa0sGZuDOwpSSFb4eKIPw&s.jpg" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">난 마카오</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
			
		<article className="card">
            <div className="product-card-image">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBJ1I4Me580mSBEctbU7oIbSGOz9Q27lE5Ig&s.jpg" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">난 조마</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
			
		<article className="card">
            <div className="product-card-image">
                <img src="https://i.namu.wiki/i/phJJ4yav60AY8ao5brb4JDnoqP0ZFJk3zaqLnE9l760V5ubk2b67VUnQzz73oeVaJRm49I_Fr32QqU36RyddNw.webp" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">우리 사이좋게 지내요</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
		
		<article className="card">
            <div className="product-card-image">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTQtg5CsXcBWxl7aSa0sGZuDOwpSSFb4eKIPw&s.jpg" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">난 마카오</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
			
		<article className="card">
            <div className="product-card-image">
                <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBJ1I4Me580mSBEctbU7oIbSGOz9Q27lE5Ig&s.jpg" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">난 조마</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
			
		<article className="card">
            <div className="product-card-image">
                <img src="https://i.namu.wiki/i/phJJ4yav60AY8ao5brb4JDnoqP0ZFJk3zaqLnE9l760V5ubk2b67VUnQzz73oeVaJRm49I_Fr32QqU36RyddNw.webp" alt="Product" />
                <div className="product-card-content">
                    <h3 className="product-card-title">
						<div className='product-buttons'>
                        <button className="product-button">구매하기</button>
                        <button className="product-button">장바구니</button>
                        </div>
						<span className="product-name">우리 사이좋게 지내요</span>
                        <span className="product-price-wrapper">
                            <span className="product-price-current">
                                117,000원
                            </span>
                        </span>
                    </h3>
                </div>
            </div>
        </article>
		

		</div>
		</div>
	</div>
  );
}

export default ProductComponent2;
